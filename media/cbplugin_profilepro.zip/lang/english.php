<?php
if ( ! ( defined( '_VALID_CB' ) || defined( '_JEXEC' ) || defined( '_VALID_MOS' ) ) ) { die( 'Direct Access to this location is not allowed.' ); }

DEFINE('Insert Community Builder Field into the Profile Page','Insert Community Builder Field into the Profile Page');
DEFINE('No profile page specified','No profile page specified');
DEFINE('Field:','Field:');
DEFINE('Class:','Class:');
DEFINE('Show Field Title:','Show Field Title:');
DEFINE('Yes ','Yes ');
DEFINE('No ','No ');
DEFINE('Field Title Class:','Field Title Class:');
DEFINE('Delimeter:','Delimeter:');
DEFINE('Insert','Insert');
DEFINE('<-- Choose Community Builder Field to insert -->','<-- Choose Community Builder Field to insert -->');
DEFINE('Home','Home');
DEFINE('Page 1','Page 1');
DEFINE('Page 2','Page 2');
DEFINE('Page 3','Page 3');
DEFINE('Page 4','Page 4');
DEFINE('Page 5','Page 5');
DEFINE('Page 6','Page 6');
DEFINE('Page 7','Page 7');

