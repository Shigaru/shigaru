USE 'AS IS', UNDER YOUR OWN RISK! 

Just want to contribute to the Joomla community. Please note that I am not a programmer. I consider my self a modder. This CB plugin idea is
based on my own needs. Have done extensive testing and it seems to be working nicely. It took a couple of days to develop the plugin, test and fix.

To my knowledge this is the first CB networks user plugin as per JED. It just show user Social Networks under a CB tab.

Please note that only major social networks have been included. This to avoid overpopulation of CB fields -- which can be problematic on large CB installations. To only show network images (and links) keep the CB Social Networks fields _unpublished_ from profile!

Install is a three step...

1- install CB plugin
2- publish CB plugin
3- publish Social Networks tab


Thank you.

Edfel Rivera
webmaster@juntehispano.com

p.d.
Please don't remove the link to my site. I used just one character to make the link less noticeable. I hope it is not too much to ask after working on this.

changelog

v1.0 (internal use only)
= Plugin supports Facebook, myspace and twitter.

1.1  (first public release)
= Plugin supports Facebook, myspace, twitter, linkedin, flickr, hi5, google, youtube, blogger and wordpress
+ added networks icons
+ added developer link

1.2
+ Fixed ugly bug that occurs if myspace url was empty

