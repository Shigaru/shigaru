=============================FREICHAT 3.1=======================================

STEPS TO INSTALL FREICHAT (FREECHAT 3.1) FOR JOOMLA 1.5 AND CB

*If you had installed a previous version of freichat 
						---make sure you uninstall/delete the component and the module 
						---delete the folders /components/com_freichat  if exists
						---delete the folders /modules/mod_freichat  if exists



1. Install com_freichat.zip from joomla install/uninstall
2. Then, install mod_freichat.zip from joomla install/uninstall
3. Enable the mod_freichat module from the module manager
4. Edit mod_freichat as following:
		*Show Title: No
		*Access Level :Registered
================================================================================
Requirements:
*Joomla with community builder
*Connections must be Enabled
*at least 2 people that are connected must be online to chat(thats what chat is for? :))		
================================================================================		

For any queries or bugs please visit the forums:
http://evnix.co.cc

Changes Made:
1.you will be able to chat even while you browse different pages.
2.option for nickname/username.
3.single css file for both(chatbar n chatbox)! and some performance updates!
4.some images added
5.And many more!
