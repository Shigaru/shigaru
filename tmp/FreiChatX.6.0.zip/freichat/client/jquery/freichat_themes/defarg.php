<?php

//If you have changed name of any images in your custom theme folder dont forget
//  to change them here
// Note: argument.php and css.php are connected
// Do not used and forward or backward slash unless the images are within
// subfolders

$mailimg = 'mail.gifupdated';
$saveimg = 'save.gifupdated';
$arrowimg = 'arrow.jpegupdated';
$smileyimg = 'smiley.pngupdated';
$translatedisabledimg = 'translatedisabled.pngupdated';
$translateimg = 'translate.gifupdated'; //Minimize image
?>