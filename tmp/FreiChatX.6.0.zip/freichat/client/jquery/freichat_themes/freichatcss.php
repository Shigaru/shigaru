<?php

header("Content-Type: text/css");
require_once '../../../arg.php';
require $freichat_theme . '/css.php';
?>