<html>
    <head>
        <title>
            Welcome to FreiChatX
        </title>
        <style type="text/css">
            body{
                background-attachment:fixed;
                background-position:center;
                background-repeat:no-repeat;
            }
            input.btnhov { 
                border-color: #c63 #930 #930 #c63; 
            }
            input.btn { 
                color:#050; 
                font: bold 84% 'trebuchet ms',helvetica,sans-serif; 
                background-color:#fed; 
                border: 1px solid; 
                border-color: #696 #363 #363 #696; 
                filter:progid:DXImageTransform.Microsoft.Gradient 
                    (GradientType=0,StartColorStr='#ffffffff',EndColorStr='#ffeeddaa'); 
            } 
        </style>
    </head>
    <body>

        <div>

            <img src="server/admin_files/home/head.png" height=100 width=100% />
        </div>
        <table border=0 cellpadding=5>

            <p>
                <b>
                    This is the index file of freichat ,
                    Sorry you cannot do anything here , but below two links may help you !
                </b>
            </p>
            <br/>
            <h2>FreiChatX INSTALLATION</h2>
            <a href = 'installation/index.php'>Go to Install FreiChatX</a>
            <br/><br/>

            <p>Already installed ? NO problems !

            <h2>FreiChatX ADMINISTRATION</h2>
            <a href = 'administrator/index.php'>Go to FreiChatX administration</a>
            <br/><br/>
            <br/><br/>
            Or did you come up at the wrong place, just click back , but be sure to be BACK !<br/>
            <FORM><INPUT TYPE="button" VALUE="Back" class="btn" onmouseout="this.className='btn'" onmouseover="this.className='btn btnhov'" onClick="history.go(-1);return true;"></FORM> 

    </body>
</html>
