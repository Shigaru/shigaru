<?php
//FreiChatX Translation For The German Language
//cb->chatbox
//g->guest
//pwd->powered
//Do not use space but nbsp;
//Always return 1 at end of line

$frei_trans['cb_head']="User";
$frei_trans['g_prefix']="Gast-";
$frei_trans['pwdby']="Powered By";
$frei_trans['noline']="Niemand online";
$frei_trans['noperms']="Bitte&nbsp;einloggen um&nbsp;zu chatten!";
$frei_trans['on_offline']="Empfange User-Daten<br/>Bitte warten<br/>..............................";
$frei_trans['go_online']="Online";
$frei_trans['go_offline']="Offline";
$frei_trans['go_invisible']="Unsichtbar";
$frei_trans['go_anonymous']="Anonym";
$frei_trans['go_busy']="Besch&auml;ftigt";
$frei_trans['newmesg']="Neue Nachricht von";
$frei_trans['status_txt']="&Auml;nderungsstand";

return 1;
?>