<?php
//FreiChatX Translation For The English Language
//cb->chatbox
//g->guest
//pwd->powered
//Do not use space but nbsp;


$frei_trans['cb_head']="User";
$frei_trans['g_prefix']="Vendég-";
$frei_trans['pwdby']="Powered By";
$frei_trans['noline']="Nincs user";
$frei_trans['noperms']="Please&nbsp;LogIn&nbsp;to chat!";
$frei_trans['on_offline']="Fetching...User..List<br/>Querying DataBase<br/>..............................";
$frei_trans['go_online']="Online";
$frei_trans['go_offline']="Offline";
$frei_trans['go_invisible']="Rejtett";
$frei_trans['go_anonymous']="Névtelenül";
$frei_trans['go_busy']="Elfoglalt";
$frei_trans['newmesg']="Új üzenet";
$frei_trans['restore_drag_pos']="Restore Positions";
$frei_trans['status_txt']="Státusz";
$frei_trans['opt_txt']="Additional Options";

return 1;

/*Language file contributed by
Name    : encipoly
Email   : kis.erno@digitalvac.hu
*/
?>