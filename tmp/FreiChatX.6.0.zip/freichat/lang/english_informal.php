<?php
//FreiChatX Translation For The English Language
//cb->chatbox
//g->guest
//pwd->powered
//Do not use space but nbsp;



$frei_trans['cb_head']="Users";
$frei_trans['g_prefix']="Visitor-";
$frei_trans['pwdby']="Powered By";
$frei_trans['noline']="No users online";
$frei_trans['noperms']="You&nbsp;need&nbsp;to&nbsp;LogIn";
$frei_trans['on_offline']="Getting list of users<br/>Requesting Database<br/>.........................";
$frei_trans['go_online']="Be Online";
$frei_trans['go_offline']="Be Offline";
$frei_trans['go_invisible']="Be Invisible";
$frei_trans['go_anonymous']="Be Anonymous";
$frei_trans['go_busy']="Be Busy";
$frei_trans['newmesg']="New Message! From";
$frei_trans['restore_drag_pos']="Reset Positions";
$frei_trans['status_txt']="Alter Status :";

return 1;
?>