<?php
/**
 * @package		JomSocial
 * @subpackage 	Template 
 * @copyright (C) 2008 by Slashes & Dots Sdn Bhd - All rights reserved!
 * @license http://www.azrul.com Copyrighted Commercial Software
 * 
 * @param	my	Current browser's CUser object.
 **/
defined('_JEXEC') or die();
?>

<table border="0" cellpadding="8" width="100%">
	<tr>
		<td valign="top">
			<div class="app-box">
				<div>
					<h2 class="app-box-title" style="margin: 0 0 20px;"><?php echo JText::_('CC UPLOAD NEW PICTURE HEADING');?>
					    <?php if($firstLogin == 'Y'){ echo '<a href="'.$skipLink.'">[Skip]</a>';} ?>
					</h2>
			    </div>
				<form action="<?php echo JRequest::getURI();?>" id="uploadForm" method="post" enctype="multipart/form-data">
				<div>
					<input class="inputbox button" type="file" id="file-upload" name="Filedata" style="color: #666;" />
					<input class="button" size="30" type="submit" onclick="return cValidateFile();" id="file-upload-submit" value="<?php echo JText::_('CC BUTTON UPLOAD PICTURE');?>">
					<p><?php echo JText::_('CC UPLOAD NEW PICTURE DESCRIPTION');?></p>
					<input type="hidden" name="action" value="doUpload" />
				</div>
				</form>
			</div>
		</td>
	</tr>
	<tr>
		<td>
		    <h2 class="app-box-title" style="margin: 0 0 20px;"><?php echo JText::_('CC PICTURE LARGE HEADING');?></h2>
		    <p><?php echo JText::_('CC LARGE PICTURE DESCRIPTION');?></p>
			<img src="<?php echo $my->getAvatar();?>" border="0" />
		</td>
	</tr>
	<tr>
		<td>
		    <h2 class="app-box-title" style="margin: 0 0 20px;"><?php echo JText::_('CC PICTURE THUMB HEADING');?></h2>
		    <p><?php echo JText::_('CC SMALL PICTURE DESCRIPTION');?></p>
			<img src="<?php echo $my->getThumbAvatar();?>" border="0" />
		</td>
	</tr>
</table>

