<?php echo $header;?>
<div class="js-sidebar">

<div class="js-right">
<?php
$module_position = "js-right";
$attribs = array("style" => "xhtml");
$subModules = &JModuleHelper::getModules($module_position);
foreach($subModules as $subModule)
{
JModuleHelper::renderModule($subModule, $attribs);
print $subModule->content;
}
?>
</div>

    <div class="app-box">
<!-- Search -->
<h2 class="app-box-title" style="margin-bottom: 10px;"><?php echo JText::_('CC SEARCH'); ?></h2>
<form name="search" id="cFormSearch" method="POST" action="<?php echo CRoute::_('index.php?option=com_community&view=search');?>">
    <input type="text" class="inputbox" id="keyword" name="q" />
    <input type="submit" name="submit" value="<?php echo JText::_('CC SEARCH'); ?>" class="button" />
</form>
<div class="clr"></div>
</div>
<!-- Search -->

<!-- Latest Photo -->
<?php if($config->get('enablephotos')){ ?>
<div class="app-box">

<h2 class="app-box-title" style="position: relative;">
<?php echo JText::_('CC NEW PHOTOS'); ?>
</h2>
<div class="see-all">
<a href="<?php echo CRoute::_('index.php?option=com_community&view=photos' ); ?>" class="app-title-link">
<span><?php echo JText::_('CC SHOW ALL'); ?></span>
</a>
</div>
<ul style="margin: 0pt; padding: 0pt; list-style: none;">
<?php
for( $i = 0 ; $i < count( $latestPhotos ); $i++ )
{
$row=& $latestPhotos[$i];
?>
    <li style="display: inline; padding: 0; background: none; margin: 0 3px 0 0 !important;">
<a href="<?php echo CRoute::_('index.php?option=com_community&view=photos&task=photo&albumid=' . $row->albumid . '&photoid=' . $row->id . '&userid=' . $row->user->id) . '#photoid=' . $row->id;?>"><img class="avatar hasTip" title="<?php echo $row->caption;?>::<?php echo JText::sprintf('Uploaded by %1$s' , $row->user->getDisplayName() );?>" src="<?php echo JURI::base() . $row->thumbnail; ?>" alt="<?php echo $row->caption;?>" width="45" height="45" /></a>
</li>
<?php
}
?>
</ul>

</div>
<?php } ?>
<!-- Latest Photo -->

<!-- Who's online -->
<div class="app-box">
<h2 class="app-box-title" style="margin-bottom: 10px;"><?php echo JText::_('CC WHOSE ONLINE'); ?></h2>
<ul class="application-group-avatars" style="margin: 0pt; padding: 0pt; list-style: none;">
<?php
for( $i = 0 ; $i < count( $onlineMembers ); $i++ )
{
$row=& $onlineMembers[$i];
?>
    <li style="display: inline; padding: 0; background: none; margin: 0 3px 0 0 !important;">
<a href="<?php echo CRoute::_('index.php?option=com_community&view=profile&userid='.$row->id ); ?>"><img class="avatar hasTip" src="<?php echo $row->user->getThumbAvatar(); ?>" title="<?php echo cAvatarTooltip($row->user); ?>" width="45" height="45" /></a>
</li>
<?php
}
?>
</ul>
</div>
<!-- Who's online -->
<div class="js-right2  app-box">
<?php
$module_position = "js-right2";
$attribs = array("style" => "xhtml");
$subModules = &JModuleHelper::getModules($module_position);
foreach($subModules as $subModule)
{
JModuleHelper::renderModule($subModule, $attribs);
print $subModule->content;
}
?>
</div>

</div>

<div class="js-content">
<div class="js-top  app-box">
<?php
$module_position = "js-top";
$attribs = array("style" => "xhtml");
$subModules = &JModuleHelper::getModules($module_position);
foreach($subModules as $subModule)
{
JModuleHelper::renderModule($subModule, $attribs);
print $subModule->content;
}
?>
</div>

<div class="app-box">
<!-- Featured Members -->
<h2 class="app-box-title">
<?php echo JText::_('CC NEW MEMBERS'); ?>
</h2>

<div class="see-all">
<a href="<?php echo CRoute::_('index.php?option=com_community&view=search&task=browse' ); ?>" class="app-title-link">
<span><?php echo JText::_('CC SHOW ALL'); ?></span>
</a>
</div>

    <ul class="application-group-avatars" style="margin: 0pt; padding: 0pt; list-style: none;">
    <?php foreach ( $rows as $row ) : ?>
    <li style="display: inline; padding: 0; background: none; margin: 0 3px 0 0 !important;">
<a href="<?php echo CRoute::_('index.php?option=com_community&view=profile&userid='.$row->id ); ?>">
<img class="avatar hasTip" src="<?php echo $row->smallAvatar; ?>" title="<?php echo cAvatarTooltip($row); ?>" width="45" height="45" />
</a>
</li>
    <?php endforeach; ?>
</ul>
<!-- Featured Members -->
</div>

    <div class="app-box">
<!-- Recent Activities -->
    <?php echo $userActivities; ?>
<!-- Recent Activities -->
</div>
<div class="js-bot  app-box">
<?php
$module_position = "js-bot";
$attribs = array("style" => "xhtml");
$subModules = &JModuleHelper::getModules($module_position);
foreach($subModules as $subModule)
{
JModuleHelper::renderModule($subModule, $attribs);
print $subModule->content;
}
?>
</div>

</div>
<div class="clr"></div>
