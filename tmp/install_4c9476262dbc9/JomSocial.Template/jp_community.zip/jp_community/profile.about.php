<?php
/**
 * @package		JomSocial
 * @subpackage 	Template 
 * @copyright (C) 2008 by Slashes & Dots Sdn Bhd - All rights reserved!
 * @license http://www.azrul.com Copyrighted Commercial Software
 * 
 * @param	profile			A Profile object that contains profile fields for this specific user
 * @param	profile->
 * @params	isMine		boolean is this profile belongs to me?
 */
defined('_JEXEC') or die();
?>
	<h2 class="app-box-title" style="position: relative;">
		<?php echo JText::_('CC ABOUT ME');?>
	</h2>
	<?php if( $isMine ): ?>
	<div class="see-all">
		<a href="<?php echo CRoute::_('index.php?option=com_community&view=profile&task=edit');?>" class="app-title-link">
			<span><?php echo JText::_('CC EDIT PROFILE'); ?></span>
		</a>
	</div>
	<?php endif; ?>

	<?php foreach( $profile['fields'] as $groupName => $items ): ?>
	<ul class="profile-right-info">
		<?php if( $groupName != 'ungrouped' ): ?>
			<li class="infoGroupTitle"><?php echo ($groupName != 'ungrouped') ? $groupName : ''; ?></li>
		<?php endif; ?>

		<?php foreach( $items as $item ): ?>
			<li class="infoTitle"><?php echo $item['name']; ?></li>
	    	<li class="infoDesc">
	    		<?php if(!empty($item['searchLink'])) :?>
					<a href="<?php echo $item['searchLink']; ?>"> 
				<?php endif; ?>
				
				<?php echo CProfileLibrary::getFieldData( $item['type'] , $item['value'] ); ?>
				
				<?php if(!empty($item['searchLink'])) :?>
					</a> 
				<?php endif; ?>
			</li>
	    <?php endforeach; ?>
	</ul>
	<?php endforeach; ?>