<?php
/**
* @package JomSocial Community Template by JoomlaPraise
* @subpackage Template
* @copyright (C) 2008 by Slashes & Dots Sdn Bhd - All rights reserved!
* @license http://www.azrul.com Copyrighted Commercial Software
*
*/
defined('_JEXEC') or die();

/* Borrowed from:
* views/profile/view.html.php
* _showHeader
*/
$my = & JFactory::getUser ();
$user = & CFactory::getActiveProfile ();
$isMine = isMine($my->id, $user->id);
$profile = JArrayHelper::toObject ( $data->profile );
$profile->largeAvatar = $user->getAvatar();
$profile->status = $user->getStatus ( $data->profile ['id'] );

?>
<?php if( $isMine ): ?>
<script type="text/javascript" language="javascript">
var cur_status = '';

function changeStatus()
{
jQuery('#statustext').addClass('status-edit');
jQuery('#save-status').show();
cur_status = jQuery('#statustext').val();
}
function saveStatus()
{
if ( cur_status != jQuery('#statustext').val() ) {
var inputVal = jQuery('#statustext').val();
jax.call('community', 'status,ajaxUpdate', inputVal);
jQuery('#profile-status span#profile-status-message').html(inputVal);
jQuery('title').val(inputVal);
cur_status = inputVal;
}
jQuery('#statustext').removeClass('status-edit');
jQuery('#save-status').hide();
jQuery('#statustext').blur();
return false;
}
function saveChanges(e)
{
var unicode = e.keyCode? e.keyCode : e.charCode;
if ( unicode == 13 ) {
saveStatus();
}
}
</script>
<?php endif; ?>


<table cellpadding="0" cellspacing="0" border="0" width="100%">
<tr>
<td valign="top" class="js-prof-sidebar">
<!-- Avatar -->
<div>
<img src="<?php echo $user->getAvatar(); ?>" alt="<?php echo $user->getDisplayName(); ?>" width="160" class="profile-avatar" />
</div>
<div class="profile-karma">
<img src="<?php $karmaImgUrl = CKarma::getKarmaImage($user); echo $karmaImgUrl; ?>" />
</div>
<div class="clr"></div>
<div class="avatar-nav">
<?php echo @$header; ?>
</div>
<?php echo $about; ?>
<?php echo $friends; ?>
<?php echo $groups; ?>
</td>

<td valign="top" class="js-prof-content">

<div class="profile-main">

<div id="message" class="notice" style="display: none;"><?php echo JText::_('CC STATUS UPDATED'); ?></div>
<div class="user-status">
<div class="welcometext">
<?php if( $isMine ): ?>
<?php echo JText::sprintf($user->getDisplayName()); ?>
<?php else : ?>
<?php echo $user->getDisplayName(); ?>
<?php endif; ?>
</div>
<div class="status-point">
<div class="statustext">
<input <?php echo ($isMine ? "" : "disabled"); ?> name="statustext" id="statustext" type="text" class="status" value="<?php echo JText::_($profile->status); ?>" onfocus="changeStatus();" onblur="saveStatus();" onkeyup="saveChanges(event)" />
<button id="save-status" style="display: none;" onclick="saveStatus();"><?php echo JText::_('Save'); ?></button>
</div>
</div>
<div class="clr"></div>
</div>

<div class="info-wrapper">
<table cellpadding="3" cellspacing="3" border="0" width="100%" class="table-info">
<tr>
<td align="center" valign="top" style="width: 20%">
<div class="number"><?php echo $user->_points; ?></div>
<div class="text"><?php echo JText::_('points'); ?></div>
</td>

<td align="center" valign="top" style="width: 20%">
<a href="<?php echo CRoute::_('index.php?option=com_community&view=groups&userid='.$user->id); ?>">
<div class="number"><?php echo $totalgroups; ?></div>
<div class="text"><?php echo JText::_('groups'); ?></div>
</a>
</td>

<td align="center" valign="top" style="width: 20%">
<a href="<?php echo CRoute::_('index.php?option=com_community&view=friends&userid='.$user->id); ?>">
<div class="number"><?php echo $totalfriends; ?></div>
<div class="text"><?php echo JText::_('friends'); ?></div>
</a>
</td>

<td align="center" valign="top" style="width: 20%">
<a href="<?php echo CRoute::_('index.php?option=com_community&view=photos&task=myphotos&userid='.$user->id); ?>">
<div class="number"><?php echo $totalphotos; ?></div>
<div class="text"><?php echo JText::_('photos'); ?></div>
</a>
</td>

<td align="center" valign="top" style="width: 20%">
<div class="number">
<?php
if ( !$totalactivities == '' OR $totalactivities > 0 ) {
echo $totalactivities;
}
else {
echo 0;
}
?>
</div>
<div class="text"><?php echo JText::_('activities'); ?></div>
</td>
</tr>

</table>
</div>

<?php echo $content; ?>
<?php echo $newsfeed; ?>

</div>
</td>
</tr>
</table>