        <div id="profile-header">
<?php if( !$isMine ): ?>
    <div>
<ul>
<?php if(!$isFriend && !$isMine) { ?>
<li>
<a href="javascript:void(0)" class="icon-add-friend" onclick="cFriendConnect('<?php echo $profile->id;?>')">
<span><?php echo JText::_('CC ADD AS FRIEND'); ?></span>
</a>
</li>
<?php } ?>

<?php if($config->get('enablephotos')): ?>
<li>
<a class="icon-photos" href="<?php echo CRoute::_('index.php?option=com_community&view=photos&task=myphotos&userid='.$profile->id); ?>">
<span><?php echo JText::_('CC PHOTO GALLERY'); ?></span>
</a>
</li>
<?php endif; ?>

<?php if( !$isMine ): ?>
<li>
<a class="icon-write" onclick="<?php echo $sendMsg; ?>" href="javascript:void(0);">
<span><?php echo JText::_('CC WRITE MESSAGE'); ?></span>
</a>
</li>
<?php endif; ?>
</ul>
</div>
    <?php else : ?>
                <div id="my-profile-toolbar">
<ul class="actions">
<li class="profile">
                        <a href="<?php echo CRoute::_('index.php?option=com_community&view=profile&task=edit'); ?>">
                            <span><?php echo JText::_('CC EDIT PROFILE'); ?></span>
                        </a>
</li>
<li class="avatar">
                        <a href="<?php echo CRoute::_('index.php?option=com_community&view=profile&task=uploadAvatar'); ?>">
                            <span><?php echo JText::_('CC EDIT AVATAR'); ?></span>
                        </a>
</li>
<li class="privacy">
                        <a href="<?php echo CRoute::_('index.php?option=com_community&view=profile&task=privacy'); ?>">
                            <span><?php echo JText::_('CC EDIT PRIVACY'); ?></span>
                        </a>
</li>
</ul>

<ul class="actions">
<li class="apps">
                        <a href="<?php echo CRoute::_('index.php?option=com_community&view=apps&task=browse'); ?>">
                            <span><?php echo JText::_('CC ADD APPLICATIONS'); ?></span>
                        </a>
</li>
<li class="group">
                        <a href="<?php echo CRoute::_('index.php?option=com_community&view=groups&task=create'); ?>">
                            <span><?php echo JText::_('CC ADD GROUP'); ?></span>
                        </a>
</li>
<li class="invite">
                        <a href="<?php echo CRoute::_('index.php?option=com_community&view=friends&task=invite'); ?>">
                            <span><?php echo JText::_('CC INVITE FRIENDS'); ?></span>
                        </a>
</li>
</ul>

                <ul class="actions">
<li class="write">
                        <a href="<?php echo CRoute::_('index.php?option=com_community&view=inbox&task=write'); ?>">
                            <span><?php echo JText::_('CC WRITE MESSAGE'); ?></span>
                        </a>
</li>
<li class="inbox">
                        <a href="<?php echo CRoute::_('index.php?option=com_community&view=inbox'); ?>">
                            <span><?php echo JText::_('CC VIEW YOUR INBOX'); ?></span>
                        </a>
</li>
<?php if($config->get('enablephotos')){ ?>
<li class="photo">
                        <a href="<?php echo CRoute::_('index.php?option=com_community&view=photos&task=uploader&userid='.$profile->id); ?>">
                            <span><?php echo JText::_('CC UPLOAD PHOTOS'); ?></span>
                        </a>
</li>
<?php } ?>
</ul>
                <div class="clr">&nbsp;</div>
</div>
<div id="my-profile-notification">
<ul>
<li>
<a href="<?php echo CRoute::_('index.php?option=com_community&view=inbox'); ?>" class="inbox">
<span>
<?php echo JText::sprintf('CC NEW MESSAGES', $unread); ?>
</span>
</a>
</li>
<li>
<a href="<?php echo CRoute::_('index.php?option=com_community&view=friends&task=pending'); ?>" class="friend">
<span>
<?php echo JText::sprintf('CC NEW FRIEND REQUESTS', $pending); ?>
</span>
</a>
</li>
</ul>
</div>

<?php endif; ?>
</div>
            <div class="clr">&nbsp;</div>
