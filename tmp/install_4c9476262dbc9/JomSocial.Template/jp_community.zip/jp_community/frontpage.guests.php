<?php
/**
 * @package		JomSocial
 * @subpackage 	Template 
 * @copyright (C) 2008 by Slashes & Dots Sdn Bhd - All rights reserved!
 * @license http://www.azrul.com Copyrighted Commercial Software
 * 
 */
defined('_JEXEC') or die();
?>
<div class="js-guest">
<div class="js-sidebar">
					    <div class="loginform moduletable">
					    	<form action="<?php echo JRequest::getURI();?>" method="post" name="login" id="form-login" >
					        <h3><?php echo JText::_('Members Login'); ?></h3>
					            <label>
									<?php echo JText::_('Username'); ?><br />
					                <input type="text" class="inputbox frontlogin" name="username" id="username" />
					            </label>

					            <label>
									<?php echo JText::_('Password'); ?><br />
					                <input type="password" class="inputbox frontlogin" name="passwd" id="password" />
					            </label>

								<label for="remember">
									<input type="checkbox" alt="<?php echo JText::_('Remember my details'); ?>" value="yes" id="remember" name="remember"/>
									<?php echo JText::_('Remember my details'); ?>
								</label>
								<div style="text-align: center;">
								    <input type="submit" value="Login" name="submit" id="submit" class="button" />
									<input type="hidden" name="option" value="com_user" />
									<input type="hidden" name="task" value="login" />
									<input type="hidden" name="return" value="<?php echo $return; ?>" />
									<?php echo JHTML::_( 'form.token' ); ?>
								</div>
					        </form>
					    </div>


</div>

<div class="js-content">
					    <div class="introduction">
					        <div class="joinbutton">
								<a id="joinButton" href="<?php echo CRoute::_( 'index.php?option=com_community&view=register' , false ); ?>" title="<?php echo JText::_('JOIN US NOW, IT’S FREE!'); ?>">
								    <?php echo JText::_('JOIN US NOW, IT’S FREE!'); ?>
								</a>
						</div>
					    </div>
</div>
</div>
<div class="clr"></div>
