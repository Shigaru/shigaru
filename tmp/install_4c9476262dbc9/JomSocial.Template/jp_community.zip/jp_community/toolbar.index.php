<script src="<?php echo rtrim( JURI::base() , '/');?>/components/com_community/assets/toolbar.js" type="text/javascript"></script>
<script type="text/javascript">

</script>

<?php
$view = JRequest::getVar('view', 'frontpage', 'REQUEST');
$toolbarClass = array('frontpage'=> '', 'profile' => '', 'friends'=>'', 'apps'=>'', 'inbox'=>'' );
$toolbarClass[$view] = 'toolbar-active';
$toolbarClass['profile'] = (!$isMine && $view == 'profile') ? '':$toolbarClass['profile']; 
?>
<div id="cToolbarNav">
	<ul id="community-toolbar">
		<?php
			if( $config->get('displayhome') )
			{
		?>
	    <li id="toolbar-item-frontpage" class="<?php echo $toolbarClass['frontpage']; ?> toolbar-item">
			<a href="<?php echo CRoute::_('index.php?option=com_community'); ?>">
				Community <?php echo JText::_('CC HOME'); ?>
			</a>
		</li>
		<?php
			}
		?>
	    <li id="toolbar-item-profile" class="<?php echo $toolbarClass['profile']; ?> toolbar-item">
			<a href="<?php echo CRoute::_('index.php?option=com_community&view=profile&userid='.$my->id); ?>" onmouseover="mopen('m1')" onmouseout="mclosetime()" class="has-submenu">
			<?php echo JText::_('CC PROFILE'); ?></a>
	        <div id="m1" onmouseover="mcancelclosetime()" onmouseout="mclosetime()" style="visibility: hidden;" class="<?php echo $toolbarClass['profile']; ?>">
		        <a href="<?php echo CRoute::_('index.php?option=com_community&view=profile&task=uploadAvatar'); ?>">
					<?php echo JText::_('CC EDIT AVATAR'); ?>
				</a>
				<a href="<?php echo CRoute::_('index.php?option=com_community&view=profile&task=edit'); ?>">
					<?php echo JText::_('CC EDIT PROFILE');?>
				</a>
			    <a href="<?php echo CRoute::_('index.php?option=com_community&view=profile&task=privacy'); ?>">
					<?php echo JText::_('CC EDIT PRIVACY');?>
				</a>
	        </div>
	    </li>
	    <li id="toolbar-item-friends" class="<?php echo $toolbarClass['friends'];?> toolbar-item">
			<a href="<?php echo CRoute::_('index.php?option=com_community&view=friends&userid='. $my->id); ?>" onmouseover="mopen('m2')" onmouseout="mclosetime()" class="has-submenu"><?php echo JText::_('CC FRIENDS'); ?></a>
	        <div id="m2" onmouseover="mcancelclosetime()" onmouseout="mclosetime()" style="visibility: hidden;" class="<?php echo $toolbarClass['friends'];?>">
				<a href="<?php echo CRoute::_('index.php?option=com_community&view=friends'); ?>" class="has-separator"><?php echo JText::_('CC SHOW ALL FRIENDS'); ?></a>
				<a href="<?php echo CRoute::_('index.php?option=com_community&view=search'); ?>"><?php echo JText::_('CC SEARCH FRIENDS'); ?></a>
				<a href="<?php echo CRoute::_('index.php?option=com_community&view=friends&task=invite'); ?>"><?php echo JText::_('CC INVITE FRIENDS'); ?></a>
				<a href="<?php echo CRoute::_('index.php?option=com_community&view=friends&task=sent'); ?>"><?php echo JText::_('CC REQUEST SENT'); ?></a>
				<a href="<?php echo CRoute::_('index.php?option=com_community&view=friends&task=pending'); ?>"><?php echo JText::_('CC PENDING APPROVAL'); ?></a>
	        </div>
	    </li>
  		<li id="toolbar-item-apps" class="<?php echo $toolbarClass['apps'];?> toolbar-item">
			<a href="<?php echo CRoute::_('index.php?option=com_community&view=apps'); ?>" onmouseover="mopen('m3')" onmouseout="mclosetime()" class="has-submenu"><?php echo JText::_('CC APPLICATIONS'); ?></a>
	        <div id="m3" onmouseover="mcancelclosetime()" onmouseout="mclosetime()" style="visibility: hidden; overflow: hidden;" class="<?php echo $toolbarClass['apps'];?>">
		        <a href="<?php echo CRoute::_('index.php?option=com_community&view=apps'); ?>">
					<?php echo JText::_('CC EDIT APPS'); ?>
				</a>
			    <a href="<?php echo CRoute::_('index.php?option=com_community&view=apps&task=browse'); ?>" class="has-separator">
					<?php echo JText::_('CC BROWSE APPS'); ?>
				</a>
				<?php if($config->get('enablegroups') ): ?>
			    <a href="<?php echo CRoute::_('index.php?option=com_community&view=groups&task=mygroups&userid='. $my->id); ?>">
					<?php echo JText::_('CC GROUP');?>
				</a>
			    <?php endif; ?>
				<?php if($config->get('enablephotos')): ?>
					<a href="<?php echo CRoute::_('index.php?option=com_community&view=photos&task=myphotos&userid='. $my->id); ?>">
						<?php echo JText::_('CC PHOTOS');?>
					</a>
				<?php endif; ?>
	        </div>
		</li>
  		<li id="toolbar-item-inbox" class="<?php echo $toolbarClass['inbox'];?> toolbar-item">
			<a href="<?php echo CRoute::_('index.php?option=com_community&view=inbox'); ?>" onmouseover="mopen('m4')" onmouseout="mclosetime()" class="has-submenu"><?php echo JText::_('CC INBOX'); ?></a>
	        <div id="m4" onmouseover="mcancelclosetime()" onmouseout="mclosetime()" style="visibility: hidden;" class="<?php echo $toolbarClass['inbox'];?>">
			    <a href="<?php echo CRoute::_('index.php?option=com_community&view=inbox'); ?>"><?php echo JText::_('CC INBOX'); ?></a>
			    <a href="<?php echo CRoute::_('index.php?option=com_community&view=inbox&task=sent'); ?>"><?php echo JText::_('CC SENT'); ?></a>
				<a href="<?php echo CRoute::_('index.php?option=com_community&view=inbox&task=write'); ?>"><?php echo JText::_('CC WRITE'); ?></a>
	        </div>
		</li>
	</ul>
	
	<div class="toolbar-myname"><?php echo JText::sprintf('CC TOOLBAR GREETING' , $my->getDisplayName()); ?></div>
	<div class="clr"></div>
</div>
<?php if ( $miniheader ) : ?>
	<?php echo @$miniheader; ?>
<?php endif; ?>
