<?php
/**
 * @package		JomSocial
 * @subpackage 	Template
 * @copyright (C) 2008 by Slashes & Dots Sdn Bhd - All rights reserved!
 * @license http://www.azrul.com Copyrighted Commercial Software
 *
 * @params	isMine		boolean is this group belong to me
 * @params	categories	Array	An array of categories object
 * @params	members		Array	An array of members object
 * @params	group		Group	A group object that has the property of a group
 * @params	wallForm	string A html data that will output the walls form.
 * @params	wallContent string A html data that will output the walls data.
 */
defined('_JEXEC') or die();
?>
<div id="community-groups-wrap" style="padding-top: 20px;">
	<?php
		if( $isMine && ( $unapproved > 0 ) )
		{
	?>
	<div class="info">
		<a class="friend" href="<?php echo CRoute::_('index.php?option=com_community&view=groups&task=viewmembers&approve=1&groupid=' . $group->id);?>">
			<?php echo JText::sprintf('CC AWAITING APPROVAL' , $unapproved ); ?>
		</a>
	</div>
	<?php
		}

		if( $waitingApproval )
		{
	?>
	<div class="info">
		<span class="icon-waitingapproval"><?php echo JText::_('CC AWAITING APPROVAL USER'); ?></span>
	</div>
	<?php
		}
	?>

	<div class="community-groups">
		<div style="float: right;">
			<img src="<?php echo $group->avatar; ?>" border="0" class="profile-avatar" />
		</div>

		<div class="community-groups-right">
			<div class="community-groups-toolbar-wrapper">
				<ul class="community-groups-toolbar">
				<?php
					if( $isMine )
					{
				?>
					<li>
						<a href="index.php?option=com_community&view=groups&task=uploadavatar&groupid=<?php echo $group->id;?>">
						<?php echo JText::_('CC EDIT GROUP AVATAR');?>
						</a>
					</li>
					<li>
						<a href="javascript:void(0);" onclick="javascript:cgroups.editGroup();">
						<?php echo JText::_('CC TAB EDIT');?>
						</a>
					</li>
				<?php
					if( $isSuperAdmin )
					{
				?>
					<li>
						<a href="javascript:void(0);" onclick="javascript:cgroups.unpublishGroup('<?php echo $group->id;?>');">
							<?php echo JText::_('CC UNPUBLISH GROUP'); ?>
						</a>
					</li>
				<?php
					}
				?>
				<?php
					}

					if( (!$isMember) && !($waitingApproval) )
					{
				?>
					<li>
						<a href="javascript:void(0);" onclick="javascript:cgroups.joinGroup('<?php echo $group->id;?>');">
						<?php echo JText::_('CC TAB JOIN GROUP'); ?>
						</a>
					</li>
				<?php
					}

					if( ($isMember) && (!$isMine) && !($waitingApproval) && (isRegisteredUser()) )
					{
				?>
					<li>
						<a href="javascript:void(0);" onclick="cgroups.showLeaveGroup('<?php echo $group->id;?>');">
						<?php echo JText::_('CC TAB LEAVE GROUP');?>
						</a>
					</li>
				<?php
					}
				?>
				</ul>
			</div>

			<div id="community-group-info">
				<div class="ctitle"><?php echo JText::_('CC GROUP TITLE INFORMATION');?></div>
				<div>
					<div class="clabel"><?php echo JText::_('CC GROUP INFO CATEGORY'); ?>:</div>
					<div class="cdata" id="community-group-data-category"><?php echo $group->getCategoryName(); ?></div>
					<span class="cinput">
						<select id="category">
						<?php
							foreach( $categories as $category )
							{
						?>
							<option value="<?php echo $category->id;?>" <?php echo ($category->id == $group->categoryid) ? ' selected="true"' : ''; ?>>
								<?php echo $category->name; ?>
							</option>
						<?php
							}
						?>
						</select>
					</span>
				</div>
				<div>
					<div class="clabel"><?php echo JText::_('CC GROUP INFO NAME');?>:</div>
					<div class="cdata" id="community-group-data-name"><?php echo $group->name; ?></div>
					<span class="cinput">
						<input type="text" id="name" name="name" size="30" value="<?php echo $group->name; ?>" />
					</span>
				</div>
				<div>
					<div class="clabel"><?php echo JText::_('CC GROUP INFO DESCRIPTION');?>:</div>
					<div class="cdata" id="community-group-data-description"><?php echo $group->description; ?></div>
					<span class="cinput">
						<textarea id="description"><?php echo $group->description; ?></textarea>
					</span>
				</div>
				<div>
					<div class="clabel"><?php echo JText::_('CC GROUP INFO CREATED');?>:</div>
					<div class="cdata"><?php echo JHTML::_('date', $group->created, JText::_('DATE_FORMAT_LC')); ?></div>
				</div>
				<div>
					<div class="clabel"><?php echo JText::_('CC GROUP INFO CREATOR');?>:</div>
					<div class="cdata"><?php echo $group->getOwnerName(); ?></div>
				</div>
				<div id="community-group-info-actions">
					<input onclick="cgroups.saveGroup('<?php echo $group->id;?>');" class="button" type="button" value="<?php echo JText::_('CC BUTTON SAVE'); ?>" />
					<input onclick="cgroups.editGroup();" class="button" type="button" value="<?php echo JText::_('CC BUTTON CANCEL'); ?>" />
				</div>
			</div>

		</div>

	</div>

	<!-- start content -->
	<div style="float: right; margin:0 0 0 10px; padding: 0 0 0 10px; width:175px;">

		<!--
		Members section
		//-->
		<h2 class="app-box-title" style="position: relative;">
			<?php echo JText::sprintf('CC MEMBERS');?>
		</h2>
		<div>
			<span class="small" style="text-align: right; float: right;"><?php echo JText::sprintf('CC MEMBERS COUNT' , $membersCount ); ?></span>
			<div class="clr"></div>
		</div>
		<ul id="community-groups-members">
			<?php if($members): ?>
				<?php foreach( $members as $member ): ?>
					<li>
						<a href="<?php echo cUserLink($member->id); ?>">
						<img border="0" class="avatar hasTip" src="<?php echo $member->getThumbAvatar(); ?>" title="<?php echo cAvatarTooltip($member);?>" />
						</a>
					</li>
				<?php endforeach; ?>
			<?php endif; ?>
		</ul>
		<div style="text-align: right;">
			<a href="<?php echo CRoute::_('index.php?option=com_community&view=groups&task=viewmembers&groupid=' . $group->id);?>"><?php echo JText::_('CC SHOW ALL');?></a>
		</div>
	</div>

	<div style="margin: 0 195px 0 0;">

		<!--
		News section
		//-->
		<div class="app-box" id="community-groups-news-items">
			<div class="app-box">
				<div class="app-box-l">
					<div class="app-box-r">
						<h2 class="expand app-box-title"><?php echo JText::_('CC GROUP NEWS');?></h2>
					</div>
				</div>
			</div>
			<?php echo $bulletinsHTML; ?>
			<div style="margin-top: 20px; border-top: 1px solid #ccc; padding-top: 3px; overflow: hidden;">
				<div style="width: 50%;float: left;">
					<?php echo JText::sprintf( 'CC DISPLAYING BULLETIN COUNT' , count($bulletins) , $totalBulletin ); ?>
				</div>

				<div style="text-align: right; float: right;">
				<?php if( $isMine ): ?>
					<span style="margin-right: 5px;">
						<a href="<?php echo CRoute::_('index.php?option=com_community&view=groups&task=addnews&groupid=' . $group->id );?>">
							<?php echo JText::_('CC ADD BULLETIN');?>
						</a>
					</span>
					|
				<?php endif; ?>
					<span style="margin-left: 5px;">
						<a href="<?php echo CRoute::_('index.php?option=com_community&view=groups&task=viewbulletins&groupid=' . $group->id);?>">
							<?php echo JText::_('CC SHOW ALL BULLETINS');?>
						</a>
					</span>
				</div>
				<div class="clr"></div>
			</div>
		</div>

		<?php if($config->get('creatediscussion')): ?>
		<!--
		Discussion section
		//-->
		<div class="app-box" id="community-groups-discuss-items">
			<div class="app-box-l">
				<div class="app-box-r">
					<h2 class="expand app-box-title"><?php echo JText::_('CC DISCUSSIONS'); ?></h2>
				</div>
			</div>
			<?php echo $discussionsHTML; ?>
			<div style="margin-top: 5px;">
				<div style="width: 50%;float: left;">
					<?php echo JText::sprintf( 'CC DISPLAYING DISCUSSION COUNT' , count($discussions) , $totalDiscussion ); ?>
				</div>
				<div style="text-align: right;">
					<?php if( $isMember && !($waitingApproval) ): ?>
					<span style="margin-right: 5px;">
						<a href="<?php echo CRoute::_('index.php?option=com_community&view=groups&groupid=' . $group->id . '&task=adddiscussion');?>">
							<?php echo JText::_('CC ADD DISCUSSION');?>
						</a>
					</span>|
					<?php endif; ?>
					<span style="margin-left: 5px;">
						<a href="<?php echo CRoute::_('index.php?option=com_community&view=groups&task=viewdiscussions&groupid=' . $group->id );?>">
							<?php echo JText::_('CC SHOW ALL DISCUSSIONS');?>
						</a>
					</span>
				</div>
			</div>
		</div>
		<?php endif; ?>


		<div class="app-box">
			<div class="app-box-l">
				<div class="app-box-r">
					<h2 class="expand app-box-title"><?php echo JText::_('CC WALL');?></h2>
				</div>
			</div>

			<div>
				<?php echo $wallForm; ?>
				<div id="wallContent">
					<?php echo $wallContent; ?>
				</div>
		</div>
		</div>
	</div>
	<!-- END content -->
</div>

<?php if( $editGroup ) : ?>
<script type="text/javascript">
	cgroups.editGroup();
</script>
<?php endif; ?>
